/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.1.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QTextEdit *textEditQuantidadesDeJogadas;
    QWidget *layoutWidget1;
    QHBoxLayout *horizontalLayout_3;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLineEdit *lineEditQuantidadeDeDiscos;
    QPushButton *pushButtonCriar;
    QPushButton *pushButtonReiniciar;
    QLabel *label_6;
    QWidget *layoutWidget2;
    QVBoxLayout *verticalLayout;
    QTextEdit *textEditTorreA;
    QLabel *label_3;
    QPushButton *pushButtonA_Para_B;
    QPushButton *pushButtonA_Para_C;
    QWidget *layoutWidget3;
    QVBoxLayout *verticalLayout_2;
    QTextEdit *textEditTorreB;
    QLabel *label_4;
    QPushButton *pushButtonB_Para_A;
    QPushButton *pushButtonB_Para_C;
    QWidget *layoutWidget4;
    QVBoxLayout *verticalLayout_3;
    QTextEdit *textEditTorreC;
    QLabel *label_5;
    QPushButton *pushButtonC_Para_A;
    QPushButton *pushButtonC_Para_B;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(800, 600);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        layoutWidget = new QWidget(centralwidget);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(460, 80, 271, 73));
        horizontalLayout_2 = new QHBoxLayout(layoutWidget);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout_2->addWidget(label_2);

        textEditQuantidadesDeJogadas = new QTextEdit(layoutWidget);
        textEditQuantidadesDeJogadas->setObjectName(QString::fromUtf8("textEditQuantidadesDeJogadas"));

        horizontalLayout_2->addWidget(textEditQuantidadesDeJogadas);

        layoutWidget1 = new QWidget(centralwidget);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(10, 80, 341, 27));
        horizontalLayout_3 = new QHBoxLayout(layoutWidget1);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label = new QLabel(layoutWidget1);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        lineEditQuantidadeDeDiscos = new QLineEdit(layoutWidget1);
        lineEditQuantidadeDeDiscos->setObjectName(QString::fromUtf8("lineEditQuantidadeDeDiscos"));

        horizontalLayout->addWidget(lineEditQuantidadeDeDiscos);


        horizontalLayout_3->addLayout(horizontalLayout);

        pushButtonCriar = new QPushButton(layoutWidget1);
        pushButtonCriar->setObjectName(QString::fromUtf8("pushButtonCriar"));

        horizontalLayout_3->addWidget(pushButtonCriar);

        pushButtonReiniciar = new QPushButton(centralwidget);
        pushButtonReiniciar->setObjectName(QString::fromUtf8("pushButtonReiniciar"));
        pushButtonReiniciar->setGeometry(QRect(700, 160, 75, 31));
        label_6 = new QLabel(centralwidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(310, 10, 221, 41));
        layoutWidget2 = new QWidget(centralwidget);
        layoutWidget2->setObjectName(QString::fromUtf8("layoutWidget2"));
        layoutWidget2->setGeometry(QRect(110, 160, 81, 331));
        verticalLayout = new QVBoxLayout(layoutWidget2);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        textEditTorreA = new QTextEdit(layoutWidget2);
        textEditTorreA->setObjectName(QString::fromUtf8("textEditTorreA"));
        textEditTorreA->setEnabled(false);
        QFont font;
        font.setPointSize(16);
        font.setBold(true);
        font.setUnderline(true);
        textEditTorreA->setFont(font);
        textEditTorreA->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        textEditTorreA->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

        verticalLayout->addWidget(textEditTorreA);

        label_3 = new QLabel(layoutWidget2);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        verticalLayout->addWidget(label_3);

        pushButtonA_Para_B = new QPushButton(layoutWidget2);
        pushButtonA_Para_B->setObjectName(QString::fromUtf8("pushButtonA_Para_B"));

        verticalLayout->addWidget(pushButtonA_Para_B);

        pushButtonA_Para_C = new QPushButton(layoutWidget2);
        pushButtonA_Para_C->setObjectName(QString::fromUtf8("pushButtonA_Para_C"));

        verticalLayout->addWidget(pushButtonA_Para_C);

        layoutWidget3 = new QWidget(centralwidget);
        layoutWidget3->setObjectName(QString::fromUtf8("layoutWidget3"));
        layoutWidget3->setGeometry(QRect(340, 160, 81, 331));
        verticalLayout_2 = new QVBoxLayout(layoutWidget3);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        textEditTorreB = new QTextEdit(layoutWidget3);
        textEditTorreB->setObjectName(QString::fromUtf8("textEditTorreB"));
        textEditTorreB->setEnabled(false);
        textEditTorreB->setFont(font);
        textEditTorreB->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        textEditTorreB->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

        verticalLayout_2->addWidget(textEditTorreB);

        label_4 = new QLabel(layoutWidget3);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        verticalLayout_2->addWidget(label_4);

        pushButtonB_Para_A = new QPushButton(layoutWidget3);
        pushButtonB_Para_A->setObjectName(QString::fromUtf8("pushButtonB_Para_A"));

        verticalLayout_2->addWidget(pushButtonB_Para_A);

        pushButtonB_Para_C = new QPushButton(layoutWidget3);
        pushButtonB_Para_C->setObjectName(QString::fromUtf8("pushButtonB_Para_C"));

        verticalLayout_2->addWidget(pushButtonB_Para_C);

        layoutWidget4 = new QWidget(centralwidget);
        layoutWidget4->setObjectName(QString::fromUtf8("layoutWidget4"));
        layoutWidget4->setGeometry(QRect(550, 160, 81, 331));
        verticalLayout_3 = new QVBoxLayout(layoutWidget4);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        textEditTorreC = new QTextEdit(layoutWidget4);
        textEditTorreC->setObjectName(QString::fromUtf8("textEditTorreC"));
        textEditTorreC->setEnabled(false);
        textEditTorreC->setFont(font);
        textEditTorreC->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        textEditTorreC->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

        verticalLayout_3->addWidget(textEditTorreC);

        label_5 = new QLabel(layoutWidget4);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        verticalLayout_3->addWidget(label_5);

        pushButtonC_Para_A = new QPushButton(layoutWidget4);
        pushButtonC_Para_A->setObjectName(QString::fromUtf8("pushButtonC_Para_A"));

        verticalLayout_3->addWidget(pushButtonC_Para_A);

        pushButtonC_Para_B = new QPushButton(layoutWidget4);
        pushButtonC_Para_B->setObjectName(QString::fromUtf8("pushButtonC_Para_B"));

        verticalLayout_3->addWidget(pushButtonC_Para_B);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 21));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "Torre De Hanoi", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:11pt; font-weight:600;\">Quantidades De Jogadas:</span></p></body></html>", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600;\">Quantidade De Discos:</span></p></body></html>", nullptr));
        pushButtonCriar->setText(QCoreApplication::translate("MainWindow", "CRIAR", nullptr));
        pushButtonReiniciar->setText(QCoreApplication::translate("MainWindow", "REINICIAR", nullptr));
        label_6->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:600; color:#000000;\">TORRE DE HANOI</span></p></body></html>", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:16pt; font-weight:600;\">A</span></p></body></html>", nullptr));
        pushButtonA_Para_B->setText(QCoreApplication::translate("MainWindow", "A > B", nullptr));
        pushButtonA_Para_C->setText(QCoreApplication::translate("MainWindow", "A > C", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:16pt; font-weight:600;\">B</span></p></body></html>", nullptr));
        pushButtonB_Para_A->setText(QCoreApplication::translate("MainWindow", "B > A", nullptr));
        pushButtonB_Para_C->setText(QCoreApplication::translate("MainWindow", "B > C", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:16pt; font-weight:600;\">C</span></p></body></html>", nullptr));
        pushButtonC_Para_A->setText(QCoreApplication::translate("MainWindow", "C > A", nullptr));
        pushButtonC_Para_B->setText(QCoreApplication::translate("MainWindow", "C > B", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
