#include "Jogo.h"

namespace hlb{
Jogo::Jogo(int quantidadeDeDiscos):
     quantidadeDeJogadas (0)
{
    try {
        if(quantidadeDeDiscos < 3 || quantidadeDeDiscos > 8) throw QString("Tamanho nao pode ser menor que 3 ou maior que 8");
        torreA = new hlb::Pilha (quantidadeDeDiscos);
        torreB = new hlb::Pilha (quantidadeDeDiscos);
        torreC = new hlb::Pilha (quantidadeDeDiscos);
        for(int pos = quantidadeDeDiscos; pos >= 1; pos--){
            torreA->inserir(pos);
        }
    }  catch (std::bad_alloc&) {
        throw QString ("Não ha memória suficiente!");
    }

}

Jogo::~Jogo(){
    if(torreA) delete torreA;
    if(torreB) delete torreB;
    if(torreC) delete torreC;
    }


bool Jogo::moverTorreA_Para_TorreB()
{
    quantidadeDeJogadas++;
    if(torreA->estaVazia()) throw QString("Torre A esta vazia");
    if(torreB->estaVazia()){
        torreB->inserir(torreA->acessar());
        torreA->retirar();

    }
    else {
        if(torreA->acessar() > torreB->acessar()) throw QString("Não pode colocar um disco maior em cima de um menor");
        torreB->inserir(torreA->acessar());
        torreA->retirar();
    }
    if(vitoria()){
        return true;
    }
    return false;
}



bool Jogo::moverTorreA_Para_TorreC()   //algo de errado
{
    quantidadeDeJogadas++;
    if(torreA->estaVazia()) throw QString("Torre A esta vazia");
    if(torreC->estaVazia()){
        torreC->inserir(torreA->acessar());
        torreA->retirar();

    }
    else {
        if(torreA->acessar() > torreC->acessar()) throw QString("Não pode colocar um disco maior em cima de um menor");
        torreC->inserir(torreA->acessar());
        torreA->retirar();
    }
    if(vitoria()){
        return true;
    }
    return false;
}


bool Jogo::moverTorreB_Para_TorreA()
{
    quantidadeDeJogadas++;
    if(torreB->estaVazia()) throw QString("Torre B esta vazia");
    if(torreA->estaVazia()){
        torreA->inserir(torreB->acessar());
        torreB->retirar();

    }
    else {
        if(torreB->acessar() > torreA->acessar()) throw QString("Não pode colocar um disco maior em cima de um menor");
        torreA->inserir(torreB->acessar());
        torreB->retirar();
        }
    if(vitoria()){
        return true;
    }
    return false;
}


bool Jogo::moverTorreB_Para_TorreC()
{   quantidadeDeJogadas++;
    if(torreB->estaVazia()) throw QString("Torre B esta vazia");
    if(torreC->estaVazia()){
        torreC->inserir(torreB->acessar());
        torreB->retirar();

    }
    else {
        if(torreB->acessar() > torreC->acessar()) throw QString("Não pode colocar um disco maior em cima de um menor");
        torreC->inserir(torreB->acessar());
        torreB->retirar();
    }
    if(vitoria()){
        return true;
    }
    return false;
}


bool Jogo::moverTorreC_Para_TorreA()
{
    quantidadeDeJogadas++;
    if(torreC->estaVazia()) throw QString("Torre C esta vazia");
    if(torreA->estaVazia()){
        torreA->inserir(torreC->acessar());
        torreC->retirar();

    }
    else {
        if(torreC->acessar() > torreA->acessar()) throw QString("Não pode colocar um disco maior em cima de um menor");
        torreA->inserir(torreC->acessar());
        torreC->retirar();
    }
    if(vitoria()){
        return true;
    }
    return false;
}



bool Jogo::moverTorreC_Para_TorreB()
{
    quantidadeDeJogadas++;
    if(torreC->estaVazia()) throw QString("Torre C esta vazia");
    if(torreB->estaVazia()){
        torreB->inserir(torreC->acessar());
        torreC->retirar();

    }
    else {
        if(torreC->acessar() > torreB->acessar()) throw QString("Não pode colocar um disco maior em cima de um menor");
        torreB->inserir(torreC->acessar());
        torreC->retirar();
    }
    if(vitoria()){
        return true;
    }
    return false;
}


QString Jogo::imprimir(int numero) const
{
    if(numero == 1) return torreA->getPilha();
    if(numero == 2) return torreB->getPilha();
    if(numero == 3) return torreC->getPilha();
}

bool Jogo::vitoria() const
{
    if(torreB->estaCheia() || torreC->estaCheia()){
        return true;
    }
    return false;
}


int Jogo::getQuantidadeDeJogadas() const
{
    return quantidadeDeJogadas;
}

}
