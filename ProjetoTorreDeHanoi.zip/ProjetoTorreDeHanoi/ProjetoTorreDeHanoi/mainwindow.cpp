#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , jogo(0)
{
    ui->setupUi(this);
    ui->textEditQuantidadesDeJogadas->setEnabled(false);
    ui->textEditQuantidadesDeJogadas->setText("0");
    ui->textEditTorreA->setEnabled(false);
    ui->textEditTorreB->setEnabled(false);
    ui->textEditTorreC->setEnabled(false);
}

MainWindow::~MainWindow()
{
    delete ui;
    if(jogo) delete jogo;
}


void MainWindow::on_pushButtonCriar_clicked()
{
    try {
        jogo = new hlb::Jogo(ui->lineEditQuantidadeDeDiscos->text().toInt());
        ui->textEditTorreA->setText(jogo->imprimir(1));
        ui->pushButtonCriar->setEnabled(false);
    }  catch (QString &erro) {
        QMessageBox::information(this, "ERRO NO PROGRAMA", erro);
    }
}


void MainWindow::on_pushButtonA_Para_B_clicked()
{
    try {
        if(jogo->moverTorreA_Para_TorreB()){
            QMessageBox msgBox;
            msgBox.setText("VOCÊ GANHOU");
            msgBox.exec();
        }
        ui->textEditTorreA->setText(jogo->imprimir(1));
        ui->textEditTorreB->setText(jogo->imprimir(2));


    }  catch (QString &erro) {
        QMessageBox::information(this, "ERRO NO PROGRAMA", erro);
    }
    ui->textEditQuantidadesDeJogadas->setText(QString::number(jogo->getQuantidadeDeJogadas()));
}


void MainWindow::on_pushButtonA_Para_C_clicked()
{
    try {
        if(jogo->moverTorreA_Para_TorreC()){
            QMessageBox msgBox;
            msgBox.setText("VOCÊ GANHOU");
            msgBox.exec();
        }
        ui->textEditTorreA->setText(jogo->imprimir(1));
        ui->textEditTorreC->setText(jogo->imprimir(3));

    }  catch (QString &erro) {
        QMessageBox::information(this, "ERRO NO PROGRAMA", erro);
    }
    ui->textEditQuantidadesDeJogadas->setText(QString::number(jogo->getQuantidadeDeJogadas()));
}


void MainWindow::on_pushButtonB_Para_A_clicked()
{
    try {
        if(jogo->moverTorreB_Para_TorreA()){
            QMessageBox msgBox;
            msgBox.setText("VOCÊ GANHOU");
            msgBox.exec();
        }
        ui->textEditTorreB->setText(jogo->imprimir(2));
        ui->textEditTorreA->setText(jogo->imprimir(1));
    }  catch (QString &erro) {
        QMessageBox::information(this, "ERRO NO PROGRAMA", erro);
    }
    ui->textEditQuantidadesDeJogadas->setText(QString::number(jogo->getQuantidadeDeJogadas()));
}


void MainWindow::on_pushButtonB_Para_C_clicked()
{
    try {
        if(jogo->moverTorreB_Para_TorreC()){
            QMessageBox msgBox;
            msgBox.setText("VOCÊ GANHOU");
            msgBox.exec();
        }
        ui->textEditTorreB->setText(jogo->imprimir(2));
        ui->textEditTorreC->setText(jogo->imprimir(3));
    }  catch (QString &erro) {
        QMessageBox::information(this, "ERRO NO PROGRAMA", erro);
    }
    ui->textEditQuantidadesDeJogadas->setText(QString::number(jogo->getQuantidadeDeJogadas()));
}


void MainWindow::on_pushButtonC_Para_A_clicked()
{
    try {
        if(jogo->moverTorreC_Para_TorreA()){

            QMessageBox msgBox;
            msgBox.setText("VOCÊ GANHOU");
            msgBox.exec();
        }
        ui->textEditTorreC->setText(jogo->imprimir(3));
        ui->textEditTorreA->setText(jogo->imprimir(1));
    }  catch (QString &erro) {
        QMessageBox::information(this, "ERRO NO PROGRAMA", erro);
    }
    ui->textEditQuantidadesDeJogadas->setText(QString::number(jogo->getQuantidadeDeJogadas()));
}


void MainWindow::on_pushButtonC_Para_B_clicked()
{
    try {
        if(jogo->moverTorreC_Para_TorreB()){
            QMessageBox msgBox;
            msgBox.setText("VOCÊ GANHOU");
            msgBox.exec();
        }
        ui->textEditTorreC->setText(jogo->imprimir(3));
        ui->textEditTorreB->setText(jogo->imprimir(2));
    }  catch (QString &erro) {
        QMessageBox::information(this, "ERRO NO PROGRAMA", erro);
    }
    ui->textEditQuantidadesDeJogadas->setText(QString::number(jogo->getQuantidadeDeJogadas()));
}


void MainWindow::on_pushButtonReiniciar_clicked()
{
    ui->textEditQuantidadesDeJogadas->setText("0");
    ui->textEditTorreA->clear();
    ui->textEditTorreB->clear();
    ui->textEditTorreC->clear();
    ui->lineEditQuantidadeDeDiscos->clear();
    ui->pushButtonCriar->setEnabled(true);
}








