#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <Jogo.h>
#include <QMessageBox>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pushButtonCriar_clicked();

    void on_pushButtonA_Para_B_clicked();

    void on_pushButtonA_Para_C_clicked();

    void on_pushButtonB_Para_A_clicked();

    void on_pushButtonB_Para_C_clicked();

    void on_pushButtonC_Para_A_clicked();

    void on_pushButtonC_Para_B_clicked();

    void on_pushButtonReiniciar_clicked();

private:
    Ui::MainWindow *ui;
    hlb::Jogo *jogo;
};
#endif // MAINWINDOW_H
