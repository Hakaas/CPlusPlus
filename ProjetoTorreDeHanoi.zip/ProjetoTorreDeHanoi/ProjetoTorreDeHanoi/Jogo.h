#ifndef JOGO_H
#define JOGO_H
#include <Pilha.h>
#include <QMessageBox>

namespace hlb{
class Jogo
{
private:
    hlb::Pilha *torreA;
    hlb::Pilha *torreB;
    hlb::Pilha *torreC;
    int quantidadeDeDiscos;
    int quantidadeDeJogadas;

public:
    Jogo(int quantidadeDeDiscos);
    ~Jogo();

    bool moverTorreA_Para_TorreB();
    bool moverTorreA_Para_TorreC();

    bool moverTorreB_Para_TorreA();
    bool moverTorreB_Para_TorreC();

    bool moverTorreC_Para_TorreA();
    bool moverTorreC_Para_TorreB();

    QString imprimir(int numero) const;

    bool vitoria() const;

    int getQuantidadeDeJogadas() const;
};
}
#endif // JOGO_H
