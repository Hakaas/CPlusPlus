#include "numerocomplexo.h"

namespace hlb {
    numeroComplexo::numeroComplexo():
        parteReal(0),
        parteImaginaria(0)
    {
    }

    void numeroComplexo::set(int parteReal, int parteImaginaria)
    {
        this->parteReal = parteReal;
        this->parteImaginaria = parteImaginaria;
    }

    QString numeroComplexo::get(){
        QString aux;
        aux = QString::number(parteReal);
        if(parteImaginaria >= 0)
            aux += " + ";
        aux += QString::number(parteImaginaria);
        return aux;
    }

    numeroComplexo numeroComplexo::operator + (numeroComplexo numero){
        int real, imag;
        numeroComplexo temp;
        real = parteReal + numero.parteReal;
        imag = parteImaginaria + numero.parteImaginaria;
        temp.set(real, imag);
        return temp;
    }

    numeroComplexo numeroComplexo::operator- (numeroComplexo numero){
        int real, imag;
        numeroComplexo temp;
        real = parteReal - numero.parteReal;
        imag = parteImaginaria - numero.parteImaginaria;
        temp.set(real, imag);
        return temp;
    }

    numeroComplexo numeroComplexo::operator* (numeroComplexo numero){
        int real, imag;
        numeroComplexo temp;
        real = (parteReal * numero.parteReal) - (numero.parteImaginaria * numero.parteReal);
        imag = (parteReal * numero.parteImaginaria) + (parteImaginaria * numero.parteReal);
        temp.set(real, imag);
        return temp;
    }

    numeroComplexo numeroComplexo::operator/(numeroComplexo numero){
        int real, imag;
        numeroComplexo temp;
        real = (parteReal * numero.parteReal) + (numero.parteImaginaria * numero.parteReal) / ((numero.parteReal * numero.parteReal) + (numero.parteImaginaria * numero.parteImaginaria));
        imag = ((parteImaginaria * numero.parteReal) - (parteReal * numero.parteImaginaria)) / ((numero.parteReal * numero.parteReal) + (numero.parteImaginaria * numero.parteImaginaria));
        temp.set(real, imag);
        return temp;
    }

    bool hlb::numeroComplexo::operator==(numeroComplexo numero){
        if(parteReal == parteImaginaria) return true;
        else return false;
    }

    bool hlb::numeroComplexo::operator!=(numeroComplexo numero){
        if(parteReal != parteImaginaria) return true;
        else return false;
    }

}

