#ifndef NUMEROCOMPLEXO_H
#define NUMEROCOMPLEXO_H
#include <QString>

namespace hlb {
class numeroComplexo
{
private:
    int parteReal;
    int parteImaginaria;
public:
    numeroComplexo();
    void set(int parteReal, int parteImaginaria);

    QString get();

    numeroComplexo operator + (numeroComplexo numero);
    numeroComplexo operator - (numeroComplexo numero);
    numeroComplexo operator * (numeroComplexo numero);
    numeroComplexo operator / (numeroComplexo numero);

    bool operator == (numeroComplexo numero);
    bool operator != (numeroComplexo numero);
};
}


#endif // NUMEROCOMPLEXO_H
