#ifndef ORDENACAO_H
#define ORDENACAO_H

#include <Itens.h>


namespace hlb{
class Ordenacao
{
public:
    Ordenacao();
    static void selectionSort(Itens **VET, int tam);
    static void insertionSort(Itens **VET, int tam);
    static void bubbleSort(Itens **VET, int tam);
    static void shellSort(Itens **VET, int tam);

    //mergeSort recursivo
    static void mergeSort(Itens **A, int tam);
    static void mergeSortR(Itens **A, Itens **B, int ini, int fim);
    static void intercala(Itens **A, Itens **B, int ini, int meio, int fim);

    //quickSort Recursivo
    static void quickSort(Itens **V, int tam);
    static void quickSortR(Itens **vetor, int Esq, int Dir);
};
}
#endif // ORDENACAO_H
