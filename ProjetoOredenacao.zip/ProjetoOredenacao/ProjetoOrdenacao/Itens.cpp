#include "Itens.h"

namespace hlb{
int Itens::getChave() const
{
    return chave;
}

void Itens::setChave(int newChave)
{
    chave = newChave;
}

const QString &Itens::getNome() const
{
    return nome;
}

void Itens::setNome(const QString &newNome)
{
    nome = newNome;
}

Itens::Itens():
    chave(0),
    nome("teste")
{
}

Itens::~Itens()
{

}
}
