#include <iostream>
#include <QString>
#include <Itens.h>
#include <Ordenacao.h>
#include <TestarOrdenacao.h>
#include <ctime>

int main()
{
    try {
        int tamanho;
        hlb::Itens **vet = nullptr;

        std::cout<<"informe o tamamho: "<<"\n";
        std::cin>>tamanho;

        vet = new hlb::Itens*[tamanho];

        std::cout<<"\n\n********** V E T O R **********\n\n";

        hlb::TestarOrdenacao testar;
        testar.preencherVetor(vet, tamanho);
        for (int i = 0; i < tamanho; i++) {
            std::cout<<vet[i]->getChave()<<" , ";
        }


        hlb::Ordenacao obj;

        std::cout<<"\n\n********** S E L E C T I O N  S O R T **********\n\n";

        double tempoSelection = 0.0;
        clock_t iniSelection = clock();

        obj.selectionSort(vet, tamanho);
        for (int i = 0; i < tamanho; i++) {
            std::cout<<vet[i]->getChave()<<" , ";
        }

        clock_t fimSelection = clock();
        tempoSelection = (double)(fimSelection - iniSelection) / CLOCKS_PER_SEC;
        std::cout<<"\n\nTempo de execucao: "<< tempoSelection;

        std::cout<<"\n\n******** I N S E R T I O N  S O R T *************\n\n";

        double tempoInsertion = 0.0;
        clock_t iniInsertion = clock();

        obj.insertionSort(vet, tamanho);
        for (int i = 0; i < tamanho; i++) {
            std::cout<<vet[i]->getChave()<<" , ";
        }

        clock_t fimInsertion = clock();
        tempoInsertion = (double)(fimInsertion - iniInsertion) / CLOCKS_PER_SEC;
        std::cout<<"\n\nTempo de execucao: "<< tempoInsertion;

        std::cout<<"\n\n******** B U B B L E  S O R T *************\n\n";

        double tempoBubble = 0.0;
        clock_t iniBubble = clock();

        obj.bubbleSort(vet, tamanho);
        for (int i = 0; i < tamanho; i++) {
            std::cout<<vet[i]->getChave()<<" , ";
        }

        clock_t fimBubble = clock();
        tempoBubble = (double)(fimBubble - iniBubble) / CLOCKS_PER_SEC;
        std::cout<<"\n\nTempo de execucao: "<< tempoBubble;

        std::cout<<"\n\n************ S H E L L  S O R T ****************\n\n";

        double tempoShell = 0.0;
        clock_t iniShell = clock();

        obj.shellSort(vet, tamanho);
        for (int i = 0; i < tamanho; i++) {
            std::cout<<vet[i]->getChave()<<" , ";
        }

        clock_t fimShell = clock();
        tempoShell = (double)(fimShell - iniShell) / CLOCKS_PER_SEC;
        std::cout<<"\n\nTempo de execucao: "<< tempoShell;


        std::cout<<"\n\n************ M E R G E  S O R T ****************\n\n";

        double tempoMerge = 0.0;
        clock_t iniMerge = clock();

        obj.mergeSort(vet, tamanho);
        for (int i = 0; i < tamanho; i++) {
            std::cout<<vet[i]->getChave()<<" , ";
        }

        clock_t fimMerge = clock();
        tempoMerge = (double)(fimMerge - iniMerge) / CLOCKS_PER_SEC;
        std::cout<<"\n\nTempo de execucao: "<< tempoMerge;


        std::cout<<"\n\n************ Q U I C K  S O R T ****************\n\n";

        double tempoQuick = 0.0;
        clock_t iniQuick = clock();

        obj.quickSort(vet, tamanho);
        for (int i = 0; i < tamanho; i++) {
            std::cout<<vet[i]->getChave()<<" , ";
        }

        clock_t fimQuick = clock();
        tempoQuick = (double)(fimQuick - iniQuick) / CLOCKS_PER_SEC;
        std::cout<<"\n\nTempo de execucao: "<< tempoQuick<<"\n\n";

    }  catch (QString &erro) {
        std::cout<<"\nERRO NA LISTA\n"<<erro.toStdString()<<"\n";
    }
}
