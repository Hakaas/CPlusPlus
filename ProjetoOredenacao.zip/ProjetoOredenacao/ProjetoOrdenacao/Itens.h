#ifndef ITENS_H
#define ITENS_H

#include <QString>

namespace hlb{
class Itens
{
private:
    int chave;
    QString nome;
public:
    Itens();
    ~Itens();

    int getChave() const;
    void setChave(int newChave);

    const QString &getNome() const;
    void setNome(const QString &newNome);
};
}
#endif // ITENS_H
