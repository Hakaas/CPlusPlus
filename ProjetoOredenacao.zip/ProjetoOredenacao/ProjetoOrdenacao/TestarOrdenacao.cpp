#include "TestarOrdenacao.h"
#include <Itens.h>
#include <iostream>

namespace hlb{
TestarOrdenacao::TestarOrdenacao()
{

}

TestarOrdenacao::~TestarOrdenacao()
{
    for (int pos=0; pos < tamanho; pos++){
        delete VET[pos];
    }
}

void TestarOrdenacao::preencherVetor(Itens **vetor, int tam)
{
    tamanho = tam;
    for (int pos = 0; pos < tam; pos++) {
        vetor[pos] = new Itens;
        vetor[pos]->setChave(rand()%500001);
    }
}

Itens **TestarOrdenacao::getVET() const
{
    return VET;
}

int TestarOrdenacao::getTamanho()
{
    return tamanho;
}
}
