#ifndef TESTARORDENACAO_H
#define TESTARORDENACAO_H

#include <cstdlib>
#include <Itens.h>
#include <Ordenacao.h>

namespace hlb{
class TestarOrdenacao
{
private:
    int tamanho;
    Itens **VET;
public:
    TestarOrdenacao();
    ~TestarOrdenacao();

    void preencherVetor(Itens **vetor,int tam);

    Itens **getVET() const;

    int getTamanho();
};
}
#endif // TESTARORDENACAO_H
