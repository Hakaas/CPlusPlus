#include "Ordenacao.h"

namespace hlb{
Ordenacao::Ordenacao()
{
}

void Ordenacao::selectionSort(Itens **VET, int tam)
{
    if(VET == nullptr) return;
    int i, j, imin;
    Itens *T = nullptr;
    for(i = 0; i < tam - 1; i++){
        imin = i;
        for(j = i + 1; j < tam; j++){
            if(VET[imin]->getChave() > VET[j]->getChave()) imin = j;
        }
        if(i != imin){
            T = VET[i];
            VET[i] = VET[imin];
            VET[imin] = T;
        }
    }
}

void Ordenacao::insertionSort(Itens **VET, int tam)
{
    long int i, j;
    Itens *T = nullptr;
    if(VET != nullptr){
        for(j = 1; j < tam; j++){
            T = VET[j];
            i = j - 1;
            while(i >= 0 && VET[i]->getChave() > T->getChave()){
                VET[i + 1] = VET[i];
                i--;
            }
            VET[i + 1] = T;
        }
    }
}

void Ordenacao::bubbleSort(Itens **VET, int tam)
{
    if(VET == nullptr) return;
    int Lsuperior, bolha, j;
    Itens *Aux = nullptr;
    Lsuperior = tam - 1;
    do {
        bolha = 0;
        for(j = 0; j < Lsuperior; j++){
            if(VET[j]->getChave() > VET[j + 1]->getChave()){
                Aux = VET[j];
                VET[j] = VET[j + 1];
                VET[j + 1] = Aux;
                bolha = j;
            }
        }
        Lsuperior = bolha;
    }
    while(Lsuperior > 0);
}

void Ordenacao::shellSort(Itens **VET, int tam)
{
    int h = 1;
    while (h < tam){
        h = 3 * h + 1;
    }
    while(h >= 1){
        for(int j = h; j<tam ; j+=1){
            Itens *Aux = VET[j];
            int i=0;
            for(i=j; (i>=h) && (VET[i-h]->getChave() > Aux->getChave()); i-=h){
                VET[i] = VET[i-h];
            }
            VET[i] = Aux;
         }
        h = (h-1) / 3;
    }
}

void Ordenacao::mergeSort(Itens **A, int tam)
{
    if(A){
        Itens **B = new Itens*[tam];
        int ini = 0;
        int fim = tam - 1;
        mergeSortR(A, B, ini, fim);
        delete[] B;
    }
}


void Ordenacao::mergeSortR(Itens **A, Itens **B, int ini, int fim)
{
    if(ini == fim) return;
    else{
        int meio;
        meio = (ini + fim) / 2;
        mergeSortR(A, B, ini, meio);
        mergeSortR(A, B, meio + 1, fim);
        intercala(A, B, ini, meio, fim);
        return;
    }
}

void Ordenacao::intercala(Itens **A, Itens **B, int ini, int meio, int fim)
{
    int i = ini, j = meio + 1, k = ini;
    while(i < meio + 1 && j < fim + 1){
        if(A[i]->getChave() < A[j]->getChave()){
            B[k] = A[i]; i++; k++;
        }
        else{
            B[k] = A[j]; j++; k++;
        }
    }
    while(i < meio + 1){ //cópia restante da 1a. metade
        B[k] = A[i]; k++; i++;
    }
    while(j < fim + 1) { //cópia restante da 2a. metade
        B[k] = A[j]; k++; j++;
    }
    for(k = ini; k < fim + 1; k++){ //cópia de volta para A
        A[k] = B[k];
    }
}

void Ordenacao::quickSort(Itens **V, int tam)
{
    int inicio = 0, fim = tam - 1;
    quickSortR(V, inicio, fim);
}

void Ordenacao::quickSortR(Itens **vetor, int Esq, int Dir)
{
    Itens *x = nullptr, *aux = nullptr, *t = nullptr;
    int i = 0, j = 0;
    if(Dir > Esq){
        x = vetor[Dir];
        i = Esq;
        j = Dir - 1;
        for(;;){
            aux = vetor[i];
            while(i < Dir && aux->getChave() < x->getChave()){
                i++;
                aux = vetor[i];
            }
            aux = vetor[j];
            while(j >= Esq && aux->getChave() > x->getChave()){
                j--;
                aux = vetor[j];
            }
            if(i >= j) break;
            t = vetor[i];
            vetor[i] = vetor[j];
            vetor[j] = t;
            i++;
            j--;
        }
        t = vetor[i];
        vetor[i] = vetor[Dir];
        vetor[Dir] = t;
        quickSortR(vetor, Esq, i - 1);
        quickSortR(vetor, i + 1, Dir);
    }
}


}

