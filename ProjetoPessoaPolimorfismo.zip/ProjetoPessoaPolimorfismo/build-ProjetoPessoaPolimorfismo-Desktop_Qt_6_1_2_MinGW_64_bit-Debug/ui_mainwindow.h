/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.1.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QRadioButton *radioButton_monitor;
    QTextEdit *textEdit_Resultado;
    QRadioButton *radioButton_estudante;
    QPushButton *pushButton_executar;
    QRadioButton *radioButton_funcionario;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout;
    QLabel *label_nome;
    QLineEdit *lineEdit_nome;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_matricula;
    QLineEdit *lineEdit_matricula;
    QVBoxLayout *verticalLayout_3;
    QLabel *label_curso;
    QLineEdit *lineEdit_curso;
    QWidget *layoutWidget1;
    QHBoxLayout *horizontalLayout_2;
    QVBoxLayout *verticalLayout_4;
    QVBoxLayout *verticalLayout_5;
    QLabel *label_salario;
    QLineEdit *lineEdit_salario;
    QVBoxLayout *verticalLayout_6;
    QLabel *label_turno;
    QLineEdit *lineEdit_turno;
    QVBoxLayout *verticalLayout_7;
    QLabel *label_rg;
    QLineEdit *lineEdit_rg;
    QWidget *layoutWidget2;
    QHBoxLayout *horizontalLayout_3;
    QVBoxLayout *verticalLayout_8;
    QLabel *label_disciplina;
    QLineEdit *lineEdit_disciplina;
    QVBoxLayout *verticalLayout_9;
    QLabel *label_cargaHoraria;
    QLineEdit *lineEdit_cargaHoraria;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(835, 600);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        radioButton_monitor = new QRadioButton(centralwidget);
        radioButton_monitor->setObjectName(QString::fromUtf8("radioButton_monitor"));
        radioButton_monitor->setGeometry(QRect(580, 150, 82, 17));
        textEdit_Resultado = new QTextEdit(centralwidget);
        textEdit_Resultado->setObjectName(QString::fromUtf8("textEdit_Resultado"));
        textEdit_Resultado->setGeometry(QRect(70, 250, 581, 181));
        radioButton_estudante = new QRadioButton(centralwidget);
        radioButton_estudante->setObjectName(QString::fromUtf8("radioButton_estudante"));
        radioButton_estudante->setGeometry(QRect(580, 50, 81, 17));
        pushButton_executar = new QPushButton(centralwidget);
        pushButton_executar->setObjectName(QString::fromUtf8("pushButton_executar"));
        pushButton_executar->setGeometry(QRect(330, 212, 81, 31));
        radioButton_funcionario = new QRadioButton(centralwidget);
        radioButton_funcionario->setObjectName(QString::fromUtf8("radioButton_funcionario"));
        radioButton_funcionario->setGeometry(QRect(570, 100, 95, 17));
        layoutWidget = new QWidget(centralwidget);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(70, 30, 471, 43));
        horizontalLayout = new QHBoxLayout(layoutWidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label_nome = new QLabel(layoutWidget);
        label_nome->setObjectName(QString::fromUtf8("label_nome"));

        verticalLayout->addWidget(label_nome);

        lineEdit_nome = new QLineEdit(layoutWidget);
        lineEdit_nome->setObjectName(QString::fromUtf8("lineEdit_nome"));

        verticalLayout->addWidget(lineEdit_nome);


        horizontalLayout->addLayout(verticalLayout);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        label_matricula = new QLabel(layoutWidget);
        label_matricula->setObjectName(QString::fromUtf8("label_matricula"));

        verticalLayout_2->addWidget(label_matricula);

        lineEdit_matricula = new QLineEdit(layoutWidget);
        lineEdit_matricula->setObjectName(QString::fromUtf8("lineEdit_matricula"));

        verticalLayout_2->addWidget(lineEdit_matricula);


        horizontalLayout->addLayout(verticalLayout_2);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        label_curso = new QLabel(layoutWidget);
        label_curso->setObjectName(QString::fromUtf8("label_curso"));

        verticalLayout_3->addWidget(label_curso);

        lineEdit_curso = new QLineEdit(layoutWidget);
        lineEdit_curso->setObjectName(QString::fromUtf8("lineEdit_curso"));

        verticalLayout_3->addWidget(lineEdit_curso);


        horizontalLayout->addLayout(verticalLayout_3);

        layoutWidget1 = new QWidget(centralwidget);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(70, 80, 471, 43));
        horizontalLayout_2 = new QHBoxLayout(layoutWidget1);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));

        horizontalLayout_2->addLayout(verticalLayout_4);

        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        label_salario = new QLabel(layoutWidget1);
        label_salario->setObjectName(QString::fromUtf8("label_salario"));

        verticalLayout_5->addWidget(label_salario);

        lineEdit_salario = new QLineEdit(layoutWidget1);
        lineEdit_salario->setObjectName(QString::fromUtf8("lineEdit_salario"));

        verticalLayout_5->addWidget(lineEdit_salario);


        horizontalLayout_2->addLayout(verticalLayout_5);

        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        label_turno = new QLabel(layoutWidget1);
        label_turno->setObjectName(QString::fromUtf8("label_turno"));

        verticalLayout_6->addWidget(label_turno);

        lineEdit_turno = new QLineEdit(layoutWidget1);
        lineEdit_turno->setObjectName(QString::fromUtf8("lineEdit_turno"));

        verticalLayout_6->addWidget(lineEdit_turno);


        horizontalLayout_2->addLayout(verticalLayout_6);

        verticalLayout_7 = new QVBoxLayout();
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        label_rg = new QLabel(layoutWidget1);
        label_rg->setObjectName(QString::fromUtf8("label_rg"));

        verticalLayout_7->addWidget(label_rg);

        lineEdit_rg = new QLineEdit(layoutWidget1);
        lineEdit_rg->setObjectName(QString::fromUtf8("lineEdit_rg"));

        verticalLayout_7->addWidget(lineEdit_rg);


        horizontalLayout_2->addLayout(verticalLayout_7);

        layoutWidget2 = new QWidget(centralwidget);
        layoutWidget2->setObjectName(QString::fromUtf8("layoutWidget2"));
        layoutWidget2->setGeometry(QRect(70, 130, 471, 43));
        horizontalLayout_3 = new QHBoxLayout(layoutWidget2);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        verticalLayout_8 = new QVBoxLayout();
        verticalLayout_8->setObjectName(QString::fromUtf8("verticalLayout_8"));
        label_disciplina = new QLabel(layoutWidget2);
        label_disciplina->setObjectName(QString::fromUtf8("label_disciplina"));

        verticalLayout_8->addWidget(label_disciplina);

        lineEdit_disciplina = new QLineEdit(layoutWidget2);
        lineEdit_disciplina->setObjectName(QString::fromUtf8("lineEdit_disciplina"));

        verticalLayout_8->addWidget(lineEdit_disciplina);


        horizontalLayout_3->addLayout(verticalLayout_8);

        verticalLayout_9 = new QVBoxLayout();
        verticalLayout_9->setObjectName(QString::fromUtf8("verticalLayout_9"));
        label_cargaHoraria = new QLabel(layoutWidget2);
        label_cargaHoraria->setObjectName(QString::fromUtf8("label_cargaHoraria"));

        verticalLayout_9->addWidget(label_cargaHoraria);

        lineEdit_cargaHoraria = new QLineEdit(layoutWidget2);
        lineEdit_cargaHoraria->setObjectName(QString::fromUtf8("lineEdit_cargaHoraria"));

        verticalLayout_9->addWidget(lineEdit_cargaHoraria);


        horizontalLayout_3->addLayout(verticalLayout_9);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 835, 21));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        radioButton_monitor->setText(QCoreApplication::translate("MainWindow", "MONITOR", nullptr));
        radioButton_estudante->setText(QCoreApplication::translate("MainWindow", "ESTUDANTE", nullptr));
        pushButton_executar->setText(QCoreApplication::translate("MainWindow", "EXECUTAR", nullptr));
        radioButton_funcionario->setText(QCoreApplication::translate("MainWindow", "FUNCION\303\201RIO", nullptr));
        label_nome->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">Nome</p></body></html>", nullptr));
        label_matricula->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">Matricula</p></body></html>", nullptr));
        label_curso->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">Curso</p></body></html>", nullptr));
        label_salario->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">Salario</p></body></html>", nullptr));
        label_turno->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">Turno</p></body></html>", nullptr));
        label_rg->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">RG</p></body></html>", nullptr));
        label_disciplina->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">Disciplina</p></body></html>", nullptr));
        label_cargaHoraria->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">Carga Hor\303\241ria</p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
