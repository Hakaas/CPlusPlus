#ifndef MONITOR_H
#define MONITOR_H

#include <QString>
#include "Estudante.h"
#include "Funcionario.h"

namespace hlb{
class Monitor : public Estudante, public Funcionario
{
private:
    QString disciplina;
    int cargaHoraria;
public:
    Monitor();
    Monitor(QString nome, int matricula, QString curso, double salario, QString turno, int rg, QString disciplina, int cargaHoraria);

    const QString &getDisciplina() const;
    void setDisciplina(const QString &newDisciplina);

    int getCargaHoraria() const;
    void setCargaHoraria(int newCargaHoraria);

    virtual QString print();
};
}
#endif // MONITOR_H
