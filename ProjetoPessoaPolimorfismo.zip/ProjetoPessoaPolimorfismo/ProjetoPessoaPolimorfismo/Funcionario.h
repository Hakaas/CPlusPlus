#ifndef FUNCIONARIO_H
#define FUNCIONARIO_H

#include <QString>

namespace hlb{
class Funcionario
{
private:
    double salario;
    QString turno;
    int rg;
public:
    Funcionario();
    Funcionario(double salario, QString turno, int rg);

    //const QString &getNome() const;
    //void setNome(const QString &newNome);

    double getSalario() const;
    void setSalario(double newSalario);

    const QString &getTurno() const;
    void setTurno(const QString &newTurno);

    int getRg() const;
    void setRg(int newRg);

    virtual QString print();
};
}
#endif // FUNCIONARIO_H
