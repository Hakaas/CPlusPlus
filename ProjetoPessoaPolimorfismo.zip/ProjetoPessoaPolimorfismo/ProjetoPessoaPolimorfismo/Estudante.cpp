#include "Estudante.h"

namespace hlb{
const QString &Estudante::getNome() const
{
    return nome;
}

void Estudante::setNome(const QString &newNome)
{
    if(nome == " ") throw QString ("ERRO!! NOME NÃO PODE ESTAR VAZIO.");
    nome = newNome;
}

int Estudante::getMatricula() const
{
    return matricula;
}

void Estudante::setMatricula(int newMatricula)
{
    if(matricula < 0) throw QString ("ERRO!! MATRICULA NÃO PODE SER MENOR QUE ZERO");
    matricula = newMatricula;
}

const QString &Estudante::getCurso() const
{
    return curso;
}

void Estudante::setCurso(const QString &newCurso)
{
    if(curso == " ") throw QString ("ERRO!! CURSO NÃO PODE ESTAR VAZIO");
    curso = newCurso;
}

QString Estudante::print()
{
    QString saida;
    saida+= "\n\nNome: " + nome;
    saida+= "\nMatrícula: " + QString::number(matricula);
    saida+= "\nCurso: " + curso;
    return saida;
}

Estudante::Estudante():
    nome(""),
    matricula(0),
    curso("")
{
}

Estudante::Estudante(QString nome, int matricula, QString curso)
{
    setNome(nome);
    setMatricula(matricula);
    setCurso(curso);
}
}
