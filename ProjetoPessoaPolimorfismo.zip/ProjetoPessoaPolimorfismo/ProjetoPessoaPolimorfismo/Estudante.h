#ifndef ESTUDANTE_H
#define ESTUDANTE_H

#include <QString>


namespace hlb{
class Estudante
{
private:
    QString nome;
    int matricula;
    QString curso;
public:
    Estudante();
    Estudante(QString nome, int matricula, QString curso);

    const QString &getNome() const;
    void setNome(const QString &newNome);

    int getMatricula() const;
    void setMatricula(int newMatricula);

    const QString &getCurso() const;
    void setCurso(const QString &newCurso);

    virtual QString print();
};
}
#endif // ESTUDANTE_H
