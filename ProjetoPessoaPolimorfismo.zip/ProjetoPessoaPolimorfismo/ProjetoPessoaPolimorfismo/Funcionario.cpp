#include "Funcionario.h"

namespace hlb{
double Funcionario::getSalario() const
{
    return salario;
}

void Funcionario::setSalario(double newSalario)
{
    if(salario < 0)  throw  QString("ERRO!! SALÁRIO NÃO PODE SER MENOR QUE ZERO");
    salario = newSalario;
}

const QString &Funcionario::getTurno() const
{
    return turno;
}

void Funcionario::setTurno(const QString &newTurno)
{
    if(turno == " ") throw QString("ERRO!! TURNO NÃO PODE ESTAR VAZIO");
    turno = newTurno;
}

int Funcionario::getRg() const
{
    return rg;
}

void Funcionario::setRg(int newRg)
{
    if(rg < 0) throw QString ("ERRO!! RG NÃO PODE SER MENOR QUE ZERO");
    rg = newRg;
}

QString Funcionario::print()
{
    QString saida;
    saida+= "\n\nSalario: " + QString::number(salario);
    saida+= "\nTurno: " + turno;
    saida+= "\nRG: " + QString::number(rg);
    return saida;
}

Funcionario::Funcionario():
    salario(0),
    turno(""),
    rg(0)
{
}

Funcionario::Funcionario( double salario, QString turno, int rg)
{
    setSalario(salario);
    setTurno(turno);
    setRg(rg);
}
}
