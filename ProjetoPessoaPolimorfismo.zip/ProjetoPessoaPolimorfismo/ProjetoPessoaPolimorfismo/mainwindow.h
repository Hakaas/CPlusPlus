#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QMessageBox>
#include <QString>
#include "Estudante.h"
#include "Funcionario.h"
#include "Monitor.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_radioButton_estudante_clicked();

    void on_radioButton_funcionario_clicked();

    void on_radioButton_monitor_clicked();

    void on_pushButton_executar_clicked();

private:
    Ui::MainWindow *ui;
    hlb::Estudante objEstudante;
    hlb::Funcionario objFuncionario;
    hlb::Monitor objMonitor;

    hlb::Estudante *ESTUDANTE = 0;
    hlb::Funcionario *FUNCIONARIO = 0;
};
#endif // MAINWINDOW_H
