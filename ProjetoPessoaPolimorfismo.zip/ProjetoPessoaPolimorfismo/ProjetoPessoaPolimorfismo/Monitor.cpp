#include "Monitor.h"

namespace hlb{
const QString &Monitor::getDisciplina() const
{
    return disciplina;
}

void Monitor::setDisciplina(const QString &newDisciplina)
{
    if(disciplina == " ") throw  QString("ERRO!! DISCIPLINA NÃ PODE ESTAR VAZIA");
    disciplina = newDisciplina;
}

int Monitor::getCargaHoraria() const
{
    if(cargaHoraria < 0) throw QString("ERR0!! CARGA HORÁRIA NÃO PODE SER MENOR QUE ZERO");
    return cargaHoraria;
}

void Monitor::setCargaHoraria(int newCargaHoraria)
{
    cargaHoraria = newCargaHoraria;
}

QString Monitor::print()
{
    QString saida;
    saida += "\nNome: " + Estudante::getNome();
    saida += "\nMatricula: " + QString::number(getMatricula());
    saida += "\nCurso: " + Estudante::getCurso();

    saida+= Funcionario::print();

    saida+= "\n\nDisiplina: " + disciplina;
    saida+= "\nCarga Horaria: " + QString::number(cargaHoraria);
    return saida;
}

Monitor::Monitor():
    Estudante(),
    Funcionario(),
    disciplina(""),
    cargaHoraria(0)
{
}

Monitor::Monitor(QString nome, int matricula, QString curso, double salario, QString turno, int rg, QString disciplina, int cargaHoraria) :
    Estudante(nome, matricula, curso), Funcionario(salario, turno, rg)
{
    setDisciplina(disciplina);
    setCargaHoraria(cargaHoraria);
}
}
