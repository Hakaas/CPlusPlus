#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    ui->lineEdit_nome->setEnabled(false);
    ui->lineEdit_curso->setEnabled(false);
    ui->lineEdit_matricula->setEnabled(false);
    ui->lineEdit_turno->setEnabled(false);
    ui->lineEdit_salario->setEnabled(false);
    ui->lineEdit_rg->setEnabled(false);
    ui->lineEdit_cargaHoraria->setEnabled(false);
    ui->lineEdit_disciplina->setEnabled(false);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_radioButton_estudante_clicked()
{
    ui->lineEdit_curso->setEnabled(true);
    ui->lineEdit_matricula->setEnabled(true);
    ui->lineEdit_nome->setEnabled(true);
    ui->lineEdit_turno->setEnabled(false);
    ui->lineEdit_salario->setEnabled(false);
    ui->lineEdit_rg->setEnabled(false);
    ui->lineEdit_cargaHoraria->setEnabled(false);
    ui->lineEdit_disciplina->setEnabled(false);
}


void MainWindow::on_radioButton_funcionario_clicked()
{
    ui->lineEdit_curso->setEnabled(false);
    ui->lineEdit_matricula->setEnabled(false);
    ui->lineEdit_nome->setEnabled(true);
    ui->lineEdit_turno->setEnabled(true);
    ui->lineEdit_salario->setEnabled(true);
    ui->lineEdit_rg->setEnabled(true);
    ui->lineEdit_cargaHoraria->setEnabled(false);
    ui->lineEdit_disciplina->setEnabled(false);
}


void MainWindow::on_radioButton_monitor_clicked()
{
    ui->lineEdit_curso->setEnabled(true);
    ui->lineEdit_matricula->setEnabled(true);
    ui->lineEdit_nome->setEnabled(true);
    ui->lineEdit_turno->setEnabled(true);
    ui->lineEdit_salario->setEnabled(true);
    ui->lineEdit_rg->setEnabled(true);
    ui->lineEdit_cargaHoraria->setEnabled(true);
    ui->lineEdit_disciplina->setEnabled(true);
}


void MainWindow::on_pushButton_executar_clicked()
{
    try {
    if(ui->radioButton_estudante->isChecked()){
       objEstudante.setNome(ui->lineEdit_nome->text());
       objEstudante.setCurso(ui->lineEdit_curso->text());
       objEstudante.setMatricula(ui->lineEdit_matricula->text().toInt());

       ui->textEdit_Resultado->setText(objEstudante.print());
    }
   else if(ui->radioButton_funcionario->isChecked())
    {
        objFuncionario.setSalario(ui -> lineEdit_salario -> text().toInt());
        objFuncionario.setTurno(ui -> lineEdit_turno -> text());
        objFuncionario.setRg(ui -> lineEdit_rg -> text().toInt());


        ui -> textEdit_Resultado -> setText(objFuncionario.print());

    }
    else if(ui->radioButton_monitor->isChecked()){


        objMonitor.setDisciplina(ui->lineEdit_disciplina->text());
        objMonitor.setCargaHoraria(ui->lineEdit_cargaHoraria->text().toInt());

        objMonitor.setSalario(ui -> lineEdit_salario -> text().toInt());
        objMonitor.setTurno(ui -> lineEdit_turno -> text());
        objMonitor.setRg(ui -> lineEdit_rg -> text().toInt());

        objMonitor.setNome(ui->lineEdit_nome->text());
        objMonitor.setCurso(ui->lineEdit_curso->text());
        objMonitor.setMatricula(ui->lineEdit_matricula->text().toInt());

        ESTUDANTE = &objMonitor;

        ui -> textEdit_Resultado->setText(ESTUDANTE->print());
    }
    }catch(QString &erro){
        QMessageBox::information(this,"ERRO",erro);
    }

}

