#include "NoArvore.h"

namespace afa{
NoArvore::NoArvore(int dado):
    dado (dado),
    esquerda (0),
    direita (0)
{
}
}
