#ifndef NOARVORE_H
#define NOARVORE_H
#include <pessoa.h>

namespace afa{
class NoArvore : public pessoa
{
private:
    int dado;
    pessoa* obj;
public:
    NoArvore *direita;
    NoArvore *esquerda;
public:
    NoArvore(int dado);
    ~NoArvore();

    int getDado()const{return dado;}
    void setDado(int dado){this->dado = dado;}

    NoArvore* getDireita(){return direita;}
    void setDireita(NoArvore* direita){this->direita = direita;}

    NoArvore* getEsquerda(){return esquerda;}
    void setEsquerda(NoArvore* esquerda){this->esquerda = esquerda;}
};
}
#endif // NOARVORE_H
