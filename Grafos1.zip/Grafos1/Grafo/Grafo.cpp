#include "Grafo.h"

Grafo::Grafo(int max, int valorArestaNula) {
    numVertices = 0;
    maxVertices = max;
    arestaNula = valorArestaNula;

    marcador = new bool[maxVertices];

    vertices = new TipoItem[maxVertices];

    matrizAdjacencias = new int* [maxVertices];

    for (int i = 0; i < maxVertices; i++) {
        matrizAdjacencias[i] = new int[maxVertices];
    }

    for (int i = 0; i < maxVertices; i++) {
        for (int j = 0; j < maxVertices; j++) {
            matrizAdjacencias[i][j] = arestaNula;
        }
    }
}

Grafo::~Grafo() {
    delete[] vertices;

    for (int i = 0; i < maxVertices; i++) {
        delete[] matrizAdjacencias[i];
    }

    delete[] matrizAdjacencias;
}

int Grafo::obterIndice(TipoItem item) {
    int indice = 0;

    while (item != vertices[indice])
    {
        indice++;
    }
    // se nao achar

    return indice;
}

bool Grafo::estaCheio() {
    return (numVertices == maxVertices);
}

void Grafo::insereVertice(TipoItem item) {
    if (estaCheio()) {
        std::cout << "O numero maximo de vertices foi alcancado!\n";
    }
    else {
        vertices[numVertices] = item;
        numVertices++;
    }
}

void Grafo::insereAresta(TipoItem noSaida, TipoItem noEntrada, int peso) {
    int linha = obterIndice(noSaida);
    int coluna = obterIndice(noEntrada);

    matrizAdjacencias[linha][coluna] = peso;

    // atrizAdjacencias[coluna][linha] = peso; direcional
}

int Grafo::obterPeso(TipoItem noSaida, TipoItem noEntrada) {
    int linha = obterIndice(noSaida);
    int coluna = obterIndice(noEntrada);

    return matrizAdjacencias[linha][coluna];
}

int Grafo::obterGrau(TipoItem item) {
    int linha = obterIndice(item);
    int grau = 0;

    for (int i = 0; i < maxVertices; i++) {
        if (matrizAdjacencias[linha][i] != arestaNula) {
            grau++;
        }
    }

    return grau;
}

void Grafo::imprimirMatriz() {
    std::cout << "Matriz de adjascencia:\n";

    for (int i = 0; i < maxVertices; i++) {
        for (int j = 0; j < maxVertices; j++) {
            std::cout << matrizAdjacencias[i][j] << " ";
        }
        std::cout << std::endl;
    }
}

void Grafo::imprimirVertices() {
    std::cout << "Lista de vertices:\n";

    for (int i = 0; i < numVertices; i++) {
        std::cout << i << ": " << vertices[i] << std::endl;
    }
}

void Grafo::limparMarcador() {
    for (int i = 0; i < maxVertices; i++) {
        marcador[i] = false;
    }
}

void Grafo::buscaEmLargura(TipoItem origem, TipoItem destino) {
    FilaDinamica filavertices;
    bool encontrado = false;
    limparMarcador();
    filavertices.inserir(origem);
    do {
        TipoItem verticeAtual = filavertices.remover();
        if (verticeAtual == destino) {
            std::cout << "Visitando: " << verticeAtual << std::endl;
            std::cout << "Caminho encontrado!\n";
            encontrado = true;
        }
        else {
            int indice = obterIndice(verticeAtual);
            std::cout << "Visitando: " << verticeAtual << std::endl;
            for (int i = 0; i < maxVertices; i++) {
                if (matrizAdjacencias[indice][i] != arestaNula) {
                    if (!marcador[i]) {
                        std::cout << "Enfileirando: " << vertices[i] << std::endl;
                        filavertices.inserir(vertices[i]);
                        marcador[i] = true;
                    }
                }
            }
        }
    } while (!filavertices.estavazio() && !encontrado);
    if (!encontrado) {
        std::cout << "Caminho nao encontrado!\n";
    }
}

void Grafo::buscaEmProfundidade(TipoItem origem, TipoItem destino) {
    PilhaDinamica pilhavertices;
    bool encontrado = false;
    limparMarcador();
    pilhavertices.inserir(origem);
    do {
        TipoItem verticeAtual = pilhavertices.remover();
        if (verticeAtual == destino) {
            std::cout << "Visitando: " << verticeAtual << std::endl;
            std::cout << "Caminho encontrado!\n";
            encontrado = true;
        }
        else {
            int indice = obterIndice(verticeAtual);
            std::cout << "Visitando: " << verticeAtual << std::endl;
            for (int i = 0; i < maxVertices; i++) {
                if (matrizAdjacencias[indice][i] != arestaNula) {
                    if (!marcador[i]) {
                        std::cout << "Enfileirando: " << vertices[i] << std::endl;
                        pilhavertices.inserir(vertices[i]);
                        marcador[i] = true;
                    }
                }
            }
        }
    } while (!pilhavertices.estavazio() && !encontrado);
    if (!encontrado) {
        std::cout << "Caminho nao encontrado!\n";
    }
}
