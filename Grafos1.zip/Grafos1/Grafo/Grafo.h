#pragma once
#include <iostream>
#include "PilhaDinamica.h"
#include "FilaDinamica.h"

//typedef std::string TipoItem;

class Grafo
{
private:
    int arestaNula;
    int maxVertices;
    int numVertices;
    TipoItem* vertices;
    int** matrizAdjacencias;
    bool* marcador;

public:
    Grafo(int max, int valorArestaNula);
    ~Grafo();

    int obterIndice(TipoItem item);
    bool estaCheio();
    void insereVertice(TipoItem item);
    void insereAresta(TipoItem noSaida, TipoItem noEntrada, int peso);
    int obterPeso(TipoItem noSaida, TipoItem noEntrada);
    int obterGrau(TipoItem item);
    void imprimirMatriz();
    void imprimirVertices();

    void limparMarcador();
    void buscaEmLargura(TipoItem origem, TipoItem destino);
    void buscaEmProfundidade(TipoItem origem, TipoItem destino);
};
