#pragma once
#ifndef PILHADINAMICA_H
#define PILHADINAMICA_H

#include "No.h"

/*/
typedef int TipoItem;
struct No //Node
{
    TipoItem valor;
    No* proximo;
};
/*/

class PilhaDinamica {
private:
    No* NoTopo;

public:
    PilhaDinamica(); //construtor //dynamic stack
    ~PilhaDinamica(); //destrutor
    bool estavazio(); //isempty
    bool estacheio(); //tem memória //isfull
    void inserir(TipoItem item); //push
    TipoItem remover(); //pop
    void imprimir(); //print


};

#endif
