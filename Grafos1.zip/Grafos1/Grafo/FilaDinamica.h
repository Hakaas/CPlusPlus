#pragma once
#ifndef FILADINAMICA_H
#define FILADINAMICA_H

#include "No.h"

/*/
typedef int TipoItem;
class No
{
  public:
  TipoItem valor;
  No* proximo;
};
/*/

class FilaDinamica {

private:
    No* primeiro; //front
    No* ultimo; //rear

public:
    FilaDinamica(); // Constructor
    ~FilaDinamica(); // Destrutor
    bool estavazio(); //isEmpty
    bool estacheio(); //isFull
    void inserir(TipoItem item); //enqueue //push
    TipoItem remover(); //dequeue //pop
    void imprimir(); //print

};

#endif
