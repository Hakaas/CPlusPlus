#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow),
      matA(0),
      matB(0)
{
    ui->setupUi(this);
    ui->textEditSaidaMatA->setEnabled(false);
    ui->textEditSaidaMatB->setEnabled(false);
    ui->textEditSaidaOperacao->setEnabled(false);
    ui->tableWidgetResultado->setEnabled(false);

    ui->pushButtonMultiplicarMatA->setEnabled(false);
    ui->pushButtonMultiplicarMatB->setEnabled(false);

    ui->pushButtonPotencializacaoA->setEnabled(false);
    ui->pushButtonPotencializacaoB->setEnabled(false);

    ui->pushButtonTranspostaA->setEnabled(false);
    ui->pushButtonTranspostaB->setEnabled(false);
}

MainWindow::~MainWindow()
{
    if(matA) delete matA;
    if(matB) delete matB;
    delete ui;
}


void MainWindow::on_pushButtonCriarMatA_clicked()
{
    try {
        int qLinhas = ui->lineEditQLinhasMatA->text().toInt();
        int qColunas = ui->lineEditQColunasMatA->text().toInt();
        matA = new hlb::Matriz(qLinhas, qColunas);
        for(int l=0; l < qLinhas ; l++){
            for(int c=0; c < qColunas; c++){
                int elemento = 0;
                matA->setElemento(elemento,l,c);
                }
            }
            ui->textEditSaidaMatA->setText(matA->getMatriz());

            for(int l = 0; l < qLinhas ; l++){
                for(int c = 0; c < qColunas; c++){
                    int elemento =  QInputDialog::getInt(this, "Leitura",
                                    "Matriz A [ "+ QString::number(l) + ", "+
                                    QString::number(c) + "] = ");
                    matA->setElemento(elemento, l, c);
                    ui->textEditSaidaMatA->setText(matA->getMatriz());
                 }
            }
        ui->textEditSaidaMatA->setText(matA->getMatriz());

        matA->setConstanteK(ui->lineEditMultiplicarMatA->text().toInt());
        int k = ui->lineEditMultiplicarMatA->text().toInt();
        if(k > 0){
            ui->pushButtonMultiplicarMatA->setEnabled(true);
            ui->pushButtonPotencializacaoA->setEnabled(true);
            ui->pushButtonTranspostaA->setEnabled(true);
        }

        /*****************GRID*MATRIZ*A********************/

        if (matA->eSimetrica()){
            QString str1 = "SIM";
            QTableWidgetItem*item1 = new QTableWidgetItem(str1);
            ui->tableWidgetResultado->setItem(0,0,item1);
        }
        else {
            QString str1 = "NÃO";
            QTableWidgetItem*item1 = new QTableWidgetItem(str1);
            ui->tableWidgetResultado-> setItem(0,0,item1);
        }

        if (matA->eIdentidade()){
            QString str1 = "SIM";
            QTableWidgetItem*item1 = new QTableWidgetItem(str1);
            ui->tableWidgetResultado-> setItem(1,0,item1);
        }
        else {
            QString str1 = "NÃO";
            QTableWidgetItem*item1 = new QTableWidgetItem(str1);
            ui->tableWidgetResultado-> setItem(1,0,item1);
        }

        if(matA->triangularSuperior()){
            QString str1 = "SIM";
            QTableWidgetItem*item1 = new QTableWidgetItem(str1);
            ui->tableWidgetResultado-> setItem(2,0,item1);
        }
        else {
            QString str1 = "NÃO";
            QTableWidgetItem*item1 = new QTableWidgetItem(str1);
            ui->tableWidgetResultado-> setItem(2,0,item1);
        }

        if(matA->triangularInfeiror()){
            QString str1 = "SIM";
            QTableWidgetItem*item1 = new QTableWidgetItem(str1);
            ui->tableWidgetResultado-> setItem(3,0,item1);
        }
        else {
            QString str1 = "NÃO";
            QTableWidgetItem*item1 = new QTableWidgetItem(str1);
            ui->tableWidgetResultado-> setItem(3,0,item1);
        }

        if(matA->permutacao()){
            QString str1 = "SIM";
            QTableWidgetItem*item1 = new QTableWidgetItem(str1);
            ui->tableWidgetResultado-> setItem(4,0,item1);
        }
        else {
            QString str1 = "NÃO";
            QTableWidgetItem*item1 = new QTableWidgetItem(str1);
            ui->tableWidgetResultado-> setItem(4,0,item1);
        }

        if(matA->ortogonal()){
            QString str1 = "SIM";
            QTableWidgetItem*item1 = new QTableWidgetItem(str1);
            ui->tableWidgetResultado-> setItem(5,0,item1);
        }
        else {
            QString str1 = "NÃO";
            QTableWidgetItem*item1 = new QTableWidgetItem(str1);
            ui->tableWidgetResultado-> setItem(5,0,item1);
        }

    } catch (QString &erro) {
            QMessageBox::information(this, "ERRO", erro);
    }   catch (std::bad_alloc &erro) {
            QMessageBox::information(this, "ERRO", "Matriz A não foi criada");
    }
}

void MainWindow::on_pushButtonCriarMatB_clicked()
{
    try {
        int qLinhas = ui->lineEditQLinhasMatB->text().toInt();
        int qColunas = ui->lineEditQColunasMatB->text().toInt();
        matB = new hlb::Matriz(qLinhas, qColunas);
        for(int l=0; l < qLinhas ; l++){
            for(int c=0; c < qColunas; c++){
                int elemento = 0;
                matB->setElemento(elemento,l,c);
            }
        }
        ui->textEditSaidaMatB->setText(matB->getMatriz());

        for(int l = 0; l < qLinhas ; l++){
            for(int c = 0; c < qColunas; c++){
                int elemento =  QInputDialog::getInt(this , "Leitura",
                                "Matriz B [ "+ QString::number(l) + ", "+
                                QString::number(c) + "] = ");
                matB->setElemento(elemento, l, c);
                ui->textEditSaidaMatB->setText(matB->getMatriz());
            }
        }
        ui->textEditSaidaMatB->setText(matB->getMatriz());
        matB->setConstanteK(ui->lineEditMultiplicarMatB->text().toInt());

        int k = ui->lineEditMultiplicarMatB->text().toInt();
        if(k > 0){
            ui->pushButtonMultiplicarMatB->setEnabled(true);
            ui->pushButtonPotencializacaoB->setEnabled(true);
            ui->pushButtonTranspostaB->setEnabled(true);
        }

        /********************GRID*MATRIZ*B*******************/

        if (matB->eSimetrica()){
            QString str1 = "SIM";
            QTableWidgetItem*item1 = new QTableWidgetItem(str1);
            ui->tableWidgetResultado->setItem(0,1,item1);
        }
        else {
            QString str1 = "NÃO";
            QTableWidgetItem*item1 = new QTableWidgetItem(str1);
            ui->tableWidgetResultado-> setItem(0,1,item1);
        }

        if (matB->eIdentidade()){
            QString str1 = "SIM";
            QTableWidgetItem*item1 = new QTableWidgetItem(str1);
            ui->tableWidgetResultado-> setItem(1,1,item1);
        }
        else {
            QString str1 = "NÃO";
            QTableWidgetItem*item1 = new QTableWidgetItem(str1);
            ui->tableWidgetResultado-> setItem(1,1,item1);
        }

        if(matB->triangularSuperior()){
            QString str1 = "SIM";
            QTableWidgetItem*item1 = new QTableWidgetItem(str1);
            ui->tableWidgetResultado-> setItem(2,1,item1);
        }
        else {
            QString str1 = "NÃO";
            QTableWidgetItem*item1 = new QTableWidgetItem(str1);
            ui->tableWidgetResultado-> setItem(2,1,item1);
        }

        if(matB->triangularInfeiror()){
            QString str1 = "SIM";
            QTableWidgetItem*item1 = new QTableWidgetItem(str1);
            ui->tableWidgetResultado-> setItem(3,1,item1);
        }
        else {
            QString str1 = "NÃO";
            QTableWidgetItem*item1 = new QTableWidgetItem(str1);
            ui->tableWidgetResultado-> setItem(3,1,item1);
        }

        if(matB->permutacao()){
            QString str1 = "SIM";
            QTableWidgetItem*item1 = new QTableWidgetItem(str1);
            ui->tableWidgetResultado-> setItem(4,1,item1);
        }
        else {
            QString str1 = "NÃO";
            QTableWidgetItem*item1 = new QTableWidgetItem(str1);
            ui->tableWidgetResultado-> setItem(4,1,item1);
        }

        if(matB->ortogonal()){
            QString str1 = "SIM";
            QTableWidgetItem*item1 = new QTableWidgetItem(str1);
            ui->tableWidgetResultado-> setItem(5,1,item1);
        }
        else {
            QString str1 = "NÃO";
            QTableWidgetItem*item1 = new QTableWidgetItem(str1);
            ui->tableWidgetResultado-> setItem(5,1,item1);
        }
    }   catch (QString &erro) {
            QMessageBox::information(this, "ERRO", erro);
    }   catch (std::bad_alloc &erro) {
            QMessageBox::information(this, "ERRO", "Matriz B não foi criada");
    }
}

void MainWindow::on_pushButtonAdicionar_clicked()
{
    try {
        hlb::Matriz *resultante = matA->adicionar(matB);
        ui->labelResultado->setText("Adicionar:");
        ui->textEditSaidaOperacao->setText(resultante->getMatriz());
        delete resultante;
    }
    catch (QString &erro) {
        QMessageBox::information(this, "ERRO", erro);
    }
}

void MainWindow::on_pushButtonSubtrair_clicked()
{
    try {
        hlb::Matriz *resultante = matA->subtrair(matB);
        ui->labelResultado->setText("Subtrair:");
        ui->textEditSaidaOperacao->setText(resultante->getMatriz());
        delete resultante;
    }  catch (QString &erro) {
        QMessageBox::information(this, "ERRO", erro);
    }
}


void MainWindow::on_pushButtonMultiplicar_clicked()
{
    try {
        hlb::Matriz *resultante = matA->multiplicar(matB);
        ui->labelResultado->setText("Multiplicar:");
        ui->textEditSaidaOperacao->setText(resultante->getMatriz());
        delete resultante;
    }  catch (QString &erro) {
        QMessageBox::information(this, "ERRO", erro);
    }
}


void MainWindow::on_pushButtonGrid_clicked()
{
    try {
        if (matA->eIgual(matB)){
             QString str1 = "SIM";
             QString str2 = "SIM";
             QTableWidgetItem*item1 =new QTableWidgetItem(str1);
             ui->tableWidgetResultado-> setItem(6,0,item1);
             QTableWidgetItem*item2 =new QTableWidgetItem(str2);
             ui->tableWidgetResultado-> setItem(6,1,item2);
        }
        else {
            QString str1 = "NÃO";
            QString str2 = "NÃO";
            QTableWidgetItem*item1 =new QTableWidgetItem(str1);
            ui->tableWidgetResultado-> setItem(6,0,item1);
            QTableWidgetItem*item2 =new QTableWidgetItem(str2);
            ui->tableWidgetResultado-> setItem(6,1,item2);
        }
        if(matA->eDiferente(matB)){
            QString str1 = "SIM";
            QString str2 = "SIM";
            QTableWidgetItem*item1 =new QTableWidgetItem(str1);
            ui->tableWidgetResultado-> setItem(7,0,item1);
            QTableWidgetItem*item2 =new QTableWidgetItem(str2);
            ui->tableWidgetResultado-> setItem(7,1,item2);
        }
        else {
            QString str1 = "NÃO";
            QString str2 = "NÃO";
            QTableWidgetItem*item1 =new QTableWidgetItem(str1);
            ui->tableWidgetResultado-> setItem(7,0,item1);
            QTableWidgetItem*item2 =new QTableWidgetItem(str2);
            ui->tableWidgetResultado-> setItem(7,1,item2);
        }
    }  catch (QString &erro) {
        QMessageBox::information(this, "ERRO", erro);
    }
}

void MainWindow::on_pushButtonTranspostaB_clicked()
{
    try {
        hlb::Matriz *resultante = matB->calcularMatrizTransposta();
        ui->labelResultado->setText("Transposta de B:");
        ui->textEditSaidaOperacao->setText(resultante->getMatriz());
        delete resultante;
    }
    catch (QString &erro) {
        QMessageBox::information(this,"ERRO",erro);
    }
}


void MainWindow::on_pushButtonTranspostaA_clicked()
{
    try {
        hlb::Matriz *resultante = matA->calcularMatrizTransposta();
        ui->labelResultado->setText("Transposta de A:");
        ui->textEditSaidaOperacao->setText(resultante->getMatriz());
        delete resultante;
    }
    catch (QString &erro) {
        QMessageBox::information(this,"ERRO",erro);
    }
}


void MainWindow::on_pushButtonPotencializacaoA_clicked()
{
    try {
        int aux = ui->lineEditMultiplicarMatA->text().toInt();
        hlb::Matriz *resultante = matA->calcularPotencializacao(aux);
        ui->labelResultado->setText("Potencialização de A:");
        ui->textEditSaidaOperacao->setText(resultante->getMatriz());
        delete resultante;
    }
    catch (QString &erro) {
        QMessageBox::information(this,"ERRO",erro);
    }
}


void MainWindow::on_pushButtonPotencializacaoB_clicked()
{
    try {
        int aux = ui->lineEditMultiplicarMatB->text().toInt();
        hlb::Matriz *resultante = matB->calcularPotencializacao(aux);
        ui->labelResultado->setText("Potencializacao de B:");
        ui->textEditSaidaOperacao->setText(resultante->getMatriz());
        delete resultante;
    }
    catch (QString &erro) {
        QMessageBox::information(this,"ERRO",erro);
    }
}


void MainWindow::on_pushButtonMultiplicarMatA_clicked()
{
    try {
            hlb::Matriz *resultante = matA->multiplicarPorK();
            ui->labelResultado->setText("Multiplicação de A por K:");
            ui->textEditSaidaOperacao->setText(resultante->getMatriz());
            delete resultante;
        }
        catch (QString &erro) {
            QMessageBox::information(this,"ERRO",erro);
        }

}


void MainWindow::on_pushButtonMultiplicarMatB_clicked()
{
    try {
            hlb::Matriz *resultante = matB->multiplicarPorK();
            ui->labelResultado->setText("Multiplicação de B por K:");
            ui->textEditSaidaOperacao->setText(resultante->getMatriz());
            delete resultante;
        }
        catch (QString &erro) {
            QMessageBox::information(this,"ERRO",erro);
        }

}

