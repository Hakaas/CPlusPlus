#ifndef MATRIZ_H
#define MATRIZ_H

#include<QString>

namespace hlb{
class Matriz
{
private:
    int quantidadeDeLinhas;
    int quantidadeDeColunas;
    int *matriz;
    int constanteK;

public:
    Matriz(int qLinhas, int qColunas);
    ~Matriz();
    QString getMatriz()const;
    int getQuantidadeDeLinhas() const;
    int getQuantidadeDeColunas() const;
    void setElemento(int elemento, int linha, int coluna)const;
    int getElemento(int linha, int coluna)const;
    void setConstanteK(int newConstanteK);
    int getConstanteK() const;

    Matriz* adicionar(Matriz const * const mat)const;
    Matriz* subtrair(Matriz const * const mat)const;
    Matriz* multiplicar(Matriz const * const mat)const;
    Matriz* calcularMatrizTransposta()const;
    Matriz* calcularPotencializacao(int mat)const;
    Matriz* multiplicarPorK()const;

    bool eIgual(Matriz const * const mat)const;
    bool eDiferente(Matriz const * const mat)const;
    bool eSimetrica()const;
    bool eIdentidade()const;
    bool triangularSuperior()const;
    bool triangularInfeiror()const;
    bool permutacao()const;
    bool ortogonal()const;


};
}
#endif // MATRIZ_H
