#include "matriz.h"

namespace hlb{
int Matriz::getQuantidadeDeLinhas() const
{
    return quantidadeDeLinhas;
}

int Matriz::getQuantidadeDeColunas() const
{
    return quantidadeDeColunas;
}

int Matriz::getConstanteK() const
{
    return constanteK;
}

void Matriz::setConstanteK(int newConstanteK)
{
    constanteK = newConstanteK;
}

Matriz::Matriz(int qLinhas, int qColunas):
    quantidadeDeLinhas(0),
    quantidadeDeColunas(0),
    matriz(0),
    constanteK(0)
{
    if(qLinhas <= 0 ) throw QString("Quantidade de Linhas nao pode ser <= 0");
    if(qColunas <= 0) throw QString("Quantidade de Colunas não pode ser <= 0");
    try {
        matriz = new int[qLinhas*qColunas];
        quantidadeDeColunas = qColunas;
        quantidadeDeLinhas = qLinhas;
    }  catch (std::bad_alloc &erro) {
        throw QString("Matriz não foi criada por falta de espaço");
    }
}

Matriz::~Matriz(){
    if(matriz) delete[] matriz;
}

void Matriz::setElemento(int elemento, int linha, int coluna)const{
    if(linha<0 || linha>=quantidadeDeLinhas)
         throw QString("Linha fora do intervalo valido");
     if(coluna<0 || coluna>=quantidadeDeColunas)
         throw QString("Coluna fora do intervalo valido");
     int pos = linha*quantidadeDeColunas+coluna;
     *(matriz+pos) = elemento;
}
int Matriz::getElemento(int linha, int coluna)const{
    if(linha<0 || linha>=quantidadeDeLinhas)
        throw QString("Linha fora do intervalo valido");
    if(coluna<0 || coluna>=quantidadeDeColunas)
        throw QString("Coluna fora do intervalo valido");
    int pos = linha*quantidadeDeColunas+coluna;
    return *(matriz+pos);
}
QString Matriz::getMatriz()const{
    QString saida = "";
    for(int linha = 0; linha < getQuantidadeDeLinhas(); linha++)
    {
        for(int coluna = 0; coluna < getQuantidadeDeColunas(); coluna++)
        {
            saida += QString::number(getElemento(linha,coluna));
            saida += "  ";
        }
        saida += "\n";
    }
    return saida;
}

Matriz* Matriz::adicionar(Matriz const * const mat)const{
    if( quantidadeDeLinhas  != mat->getQuantidadeDeLinhas() ||
        quantidadeDeColunas != mat->getQuantidadeDeColunas())
        throw QString("Nao pode ser adicionadas matriz de tamanhos diferentes");
    try{
        Matriz *aux = new Matriz(quantidadeDeLinhas,quantidadeDeColunas);
        for(int linha = 0; linha < quantidadeDeLinhas; linha++){
            for(int coluna = 0; coluna < quantidadeDeColunas; coluna++){
                int valor = this->getElemento(linha,coluna) + mat->getElemento(linha,coluna);
                aux->setElemento(valor, linha, coluna);
            }
        }
        return aux;
    }
    catch(std::bad_alloc&){
        throw QString("Vai comprar Memória");
    }
    catch(QString &erro){
        throw QString("Matriz auxiliar não Criada não podemos adicionar as matrizes");
    }
}

Matriz* Matriz::subtrair(Matriz const * const mat)const{
    if( quantidadeDeLinhas  != mat->getQuantidadeDeLinhas() ||
        quantidadeDeColunas != mat->getQuantidadeDeColunas())
        throw QString("Nao pode ser adicionadas matriz de tamanhos diferentes");
    try {
        Matriz *aux = new Matriz(quantidadeDeLinhas,quantidadeDeColunas);
        for(int linha = 0; linha < quantidadeDeLinhas; linha++){
            for(int coluna = 0; coluna < quantidadeDeColunas; coluna++){
                int valor = this->getElemento(linha,coluna) - mat->getElemento(linha,coluna);
                aux->setElemento(valor, linha, coluna);
            }
        }
        return aux;

    }  catch (std::bad_alloc&) {
        throw QString("Vai comprar Memória");
    }
    catch(QString &erro){
        throw QString("Matriz auxiliar não Criada não podemos adicionar as matrizes");
    }
}

Matriz* Matriz::multiplicar(Matriz const * const mat)const{
    if(quantidadeDeColunas != mat->quantidadeDeLinhas) throw QString("Impossivel multiplicar as matrizes.");
    Matriz *aux = new Matriz(this->quantidadeDeLinhas, mat->quantidadeDeColunas);
    int aux1= 0, aux2= 0;
    for(int auxRes= 0; auxRes < this->getQuantidadeDeLinhas(); auxRes++){
        for(int linha= 0; linha < mat->getQuantidadeDeColunas(); linha++){
            int pos= 0;
            for(int coluna= 0; coluna < mat->getQuantidadeDeLinhas(); coluna++){
                if(aux2 == mat->quantidadeDeColunas){
                    aux2= 0;
                }
                pos+= this->getElemento(aux1,coluna) * mat->getElemento(coluna, aux2);

            }

            aux->setElemento(pos, aux1, aux2);
            aux2++;
        }
        aux1++;
    }
    return aux;
}

Matriz* Matriz::calcularMatrizTransposta()const{
    try {
        Matriz *aux = new Matriz(quantidadeDeColunas, quantidadeDeLinhas);

        for(int linha = 0; linha < quantidadeDeLinhas; linha++){
            for(int coluna = 0; coluna < quantidadeDeColunas; coluna++){
                int valor = getElemento(linha, coluna);
                aux->setElemento(valor, coluna, linha);
            }
        }
        return aux;
    }  catch (std::bad_alloc &erro) {
        throw QString("Erro na alocação de memória");
    }
    catch(QString &erro){
        throw QString("Não foi possível criar a matriz auxiliar, calcular transposta não efetuada");
    }
}

Matriz* Matriz::calcularPotencializacao(int mat)const{
    try{
        Matriz *aux = new Matriz(quantidadeDeLinhas, quantidadeDeColunas);
            for(int linha= 0; linha < quantidadeDeLinhas; linha++){
                for(int coluna= 0; coluna < quantidadeDeColunas; coluna++){
                    int elemento= this->getElemento(linha, coluna);
                    aux->setElemento(elemento, linha, coluna);
                }
            }

            for(int aux1= 0; aux1 < mat-1; aux1++){
                for(int linha= 0; linha < quantidadeDeLinhas; linha++){
                    for(int coluna= 0; coluna < quantidadeDeColunas; coluna++){
                        int elemento= this->getElemento(linha, coluna);
                        int elemento1= aux->getElemento(linha,coluna);
                        aux->setElemento(elemento1*elemento, linha, coluna);
                    }
                }
            }

            return aux;
    }
    catch(std::bad_alloc&){
        throw QString("Vai comprar Memoria");
    }
    catch(QString &erro){
        throw QString("Matriz auxiliar não Criada não podemos adicionar as matrizes");
    }
}

Matriz* Matriz::multiplicarPorK()const{
    try {
        Matriz *aux = new Matriz(quantidadeDeLinhas,quantidadeDeColunas);
        for(int linha = 0; linha < quantidadeDeLinhas; linha++){
            for(int coluna = 0; coluna < quantidadeDeColunas; coluna++){
                int valor = getConstanteK() * getElemento(linha, coluna);
                aux->setElemento(valor, linha, coluna);
            }
        }
        return aux;
    }  catch (std::bad_alloc&) {
        throw QString("Vai comprar Memoria");
    }
    catch(QString &erro){
        throw QString("Matriz auxiliar não Criada não podemos adicionar as matrizes");
    }
}

bool Matriz::eIgual(Matriz const * const mat)const{
    try {
        if( quantidadeDeLinhas  != mat->getQuantidadeDeLinhas() ||
            quantidadeDeColunas != mat->getQuantidadeDeColunas()) return false;

        for(int linha = 0; linha < quantidadeDeLinhas; linha++){
            for(int coluna = 0; coluna < quantidadeDeColunas; coluna++){
                if(linha == coluna && this->getElemento(linha, coluna) == mat->getElemento(linha, coluna)) return true;
            }
        }
        return false;
    }  catch (QString &erro) {
        throw QString ("Matriz auxiliar não Criada não podemos adicionar as matrizes");
    }

}

bool Matriz::eDiferente(Matriz const * const mat)const{
    try {
        if(this->quantidadeDeLinhas != mat->quantidadeDeLinhas && this->quantidadeDeColunas != mat->quantidadeDeColunas)
               return true;

           if(getMatriz() == mat->getMatriz()){
               return false;
           }
           return true;
    }  catch (QString &erro) {
        throw QString ("Matriz auxiliar não Criada não podemos adicionar as matrizes");
    }

}

bool Matriz::eSimetrica()const{
    if(quantidadeDeLinhas  != quantidadeDeColunas) return false;

    for(int linha = 0; linha < quantidadeDeLinhas; linha++){
        for(int coluna = 0; coluna < quantidadeDeColunas; coluna++){
            if(getElemento(linha, coluna) != getElemento(coluna, linha)) return false;
        }
        return true;
    }
}

bool Matriz::eIdentidade()const{
    if(quantidadeDeLinhas != quantidadeDeColunas){
        return false;
    }
    for(int linha = 0; linha < quantidadeDeLinhas; linha++){
        for(int coluna = 0; coluna < quantidadeDeColunas; coluna++){
            if(linha == coluna && getElemento(linha, coluna) != 1) return false;
            if(linha != coluna && getElemento(linha, coluna) != 0) return false;
        }
    }
    return true;
}

bool Matriz::triangularSuperior() const
{
    int k=0;
    for(int linha = 0; linha < quantidadeDeLinhas; linha++){
        for(int coluna = 0; coluna < quantidadeDeColunas; coluna++){
            if(linha == coluna && getElemento(linha, coluna) > 0 ||
               linha < coluna && getElemento(linha, coluna) == 0){
                k++;
            }
        }
    }
    if(k==quantidadeDeLinhas){
        return true;
    }
    else{
        return false;
    }

}

bool Matriz::triangularInfeiror() const
{
    int k=0;
    for(int linha = 0; linha < quantidadeDeLinhas; linha++){
        for(int coluna = 0; coluna < quantidadeDeColunas; coluna++){
            if(linha == coluna && getElemento(linha, coluna) > 0 ||
               linha > coluna && getElemento(linha, coluna) == 0){
                k++;
            }
        }
    }
    if(k==quantidadeDeLinhas){
        return true;
    }
    else {
        return false;
    }
}

bool Matriz::permutacao()const{
    if(quantidadeDeColunas != quantidadeDeLinhas) return false;

        int aux= 0;
        for(int linha= 0; linha < quantidadeDeLinhas; linha++){
            for(int coluna= 0; coluna < quantidadeDeColunas; coluna++){
                if(getElemento(linha,coluna) != 1 && getElemento(linha,coluna) != 0) return false;

                if(getElemento(linha, coluna) == 1){
                    for(int auxL= 0; auxL < quantidadeDeLinhas; auxL++){
                        if(auxL != coluna){
                            if(getElemento(linha, auxL) == 0)
                                aux++;
                            else
                                return false;
                        }
                        if(auxL != linha){
                            if(getElemento(auxL, coluna) == 0)
                                aux++;
                            else
                                return false;
                        }
                    }
                }
            }
        }
        if(aux == (quantidadeDeLinhas*(quantidadeDeColunas-1)) * 2)
            return true;

        return false;
}

 bool Matriz::ortogonal()const{
        Matriz *aux = new Matriz(quantidadeDeLinhas, quantidadeDeColunas);
        Matriz *aux2 = new Matriz(quantidadeDeLinhas, quantidadeDeColunas);
        if(quantidadeDeLinhas != quantidadeDeColunas) return false;
        aux = this->calcularMatrizTransposta();
        aux2 = this->multiplicar(aux);

        if(aux2->eIdentidade()) return true;
        if(!aux->eIdentidade()) return false;
}

}
