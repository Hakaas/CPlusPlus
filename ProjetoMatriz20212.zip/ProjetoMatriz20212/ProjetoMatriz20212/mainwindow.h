#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QString>
#include <QMessageBox>
#include <matriz.h>
#include<QInputDialog>
#include<QTableWidgetItem>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pushButtonCriarMatA_clicked();

    void on_pushButtonCriarMatB_clicked();

    void on_pushButtonAdicionar_clicked();

    void on_pushButtonSubtrair_clicked();

    void on_pushButtonMultiplicar_clicked();

    void on_pushButtonGrid_clicked();

    void on_pushButtonTranspostaB_clicked();

    void on_pushButtonTranspostaA_clicked();

    void on_pushButtonPotencializacaoA_clicked();

    void on_pushButtonPotencializacaoB_clicked();

    void on_pushButtonMultiplicarMatA_clicked();

    void on_pushButtonMultiplicarMatB_clicked();

private:
    Ui::MainWindow *ui;
    hlb::Matriz *matA;
    hlb::Matriz *matB;
};
#endif // MAINWINDOW_H
