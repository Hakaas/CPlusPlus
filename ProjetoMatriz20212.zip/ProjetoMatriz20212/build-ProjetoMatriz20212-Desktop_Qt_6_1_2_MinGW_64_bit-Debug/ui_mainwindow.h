/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.1.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QLabel *label;
    QTextEdit *textEditSaidaMatA;
    QPushButton *pushButtonCriarMatA;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout;
    QLabel *label_2;
    QLineEdit *lineEditQLinhasMatA;
    QWidget *layoutWidget1;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_3;
    QLineEdit *lineEditQColunasMatA;
    QPushButton *pushButtonCriarMatB;
    QWidget *layoutWidget_2;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_4;
    QLineEdit *lineEditQLinhasMatB;
    QLabel *label_5;
    QTextEdit *textEditSaidaMatB;
    QWidget *layoutWidget_3;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_6;
    QLineEdit *lineEditQColunasMatB;
    QTextEdit *textEditSaidaOperacao;
    QWidget *layoutWidget2;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButtonAdicionar;
    QPushButton *pushButtonSubtrair;
    QPushButton *pushButtonMultiplicar;
    QTableWidget *tableWidgetResultado;
    QPushButton *pushButtonGrid;
    QWidget *widget;
    QVBoxLayout *verticalLayout_2;
    QPushButton *pushButtonTranspostaA;
    QPushButton *pushButtonTranspostaB;
    QWidget *widget1;
    QVBoxLayout *verticalLayout_3;
    QPushButton *pushButtonPotencializacaoA;
    QPushButton *pushButtonPotencializacaoB;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(888, 769);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(100, 0, 141, 51));
        textEditSaidaMatA = new QTextEdit(centralwidget);
        textEditSaidaMatA->setObjectName(QString::fromUtf8("textEditSaidaMatA"));
        textEditSaidaMatA->setGeometry(QRect(10, 160, 341, 101));
        pushButtonCriarMatA = new QPushButton(centralwidget);
        pushButtonCriarMatA->setObjectName(QString::fromUtf8("pushButtonCriarMatA"));
        pushButtonCriarMatA->setGeometry(QRect(320, 70, 81, 32));
        layoutWidget = new QWidget(centralwidget);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(10, 70, 301, 31));
        horizontalLayout = new QHBoxLayout(layoutWidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout->addWidget(label_2);

        lineEditQLinhasMatA = new QLineEdit(layoutWidget);
        lineEditQLinhasMatA->setObjectName(QString::fromUtf8("lineEditQLinhasMatA"));
        QFont font;
        font.setPointSize(14);
        lineEditQLinhasMatA->setFont(font);

        horizontalLayout->addWidget(lineEditQLinhasMatA);

        layoutWidget1 = new QWidget(centralwidget);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(10, 110, 321, 41));
        horizontalLayout_2 = new QHBoxLayout(layoutWidget1);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        label_3 = new QLabel(layoutWidget1);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_2->addWidget(label_3);

        lineEditQColunasMatA = new QLineEdit(layoutWidget1);
        lineEditQColunasMatA->setObjectName(QString::fromUtf8("lineEditQColunasMatA"));
        lineEditQColunasMatA->setFont(font);

        horizontalLayout_2->addWidget(lineEditQColunasMatA);

        pushButtonCriarMatB = new QPushButton(centralwidget);
        pushButtonCriarMatB->setObjectName(QString::fromUtf8("pushButtonCriarMatB"));
        pushButtonCriarMatB->setGeometry(QRect(780, 70, 81, 32));
        layoutWidget_2 = new QWidget(centralwidget);
        layoutWidget_2->setObjectName(QString::fromUtf8("layoutWidget_2"));
        layoutWidget_2->setGeometry(QRect(470, 70, 301, 31));
        horizontalLayout_3 = new QHBoxLayout(layoutWidget_2);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        label_4 = new QLabel(layoutWidget_2);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        horizontalLayout_3->addWidget(label_4);

        lineEditQLinhasMatB = new QLineEdit(layoutWidget_2);
        lineEditQLinhasMatB->setObjectName(QString::fromUtf8("lineEditQLinhasMatB"));
        lineEditQLinhasMatB->setFont(font);

        horizontalLayout_3->addWidget(lineEditQLinhasMatB);

        label_5 = new QLabel(centralwidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(570, 0, 141, 41));
        textEditSaidaMatB = new QTextEdit(centralwidget);
        textEditSaidaMatB->setObjectName(QString::fromUtf8("textEditSaidaMatB"));
        textEditSaidaMatB->setGeometry(QRect(470, 160, 341, 101));
        layoutWidget_3 = new QWidget(centralwidget);
        layoutWidget_3->setObjectName(QString::fromUtf8("layoutWidget_3"));
        layoutWidget_3->setGeometry(QRect(470, 110, 321, 41));
        horizontalLayout_4 = new QHBoxLayout(layoutWidget_3);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        label_6 = new QLabel(layoutWidget_3);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        horizontalLayout_4->addWidget(label_6);

        lineEditQColunasMatB = new QLineEdit(layoutWidget_3);
        lineEditQColunasMatB->setObjectName(QString::fromUtf8("lineEditQColunasMatB"));
        lineEditQColunasMatB->setFont(font);

        horizontalLayout_4->addWidget(lineEditQColunasMatB);

        textEditSaidaOperacao = new QTextEdit(centralwidget);
        textEditSaidaOperacao->setObjectName(QString::fromUtf8("textEditSaidaOperacao"));
        textEditSaidaOperacao->setGeometry(QRect(90, 270, 241, 101));
        layoutWidget2 = new QWidget(centralwidget);
        layoutWidget2->setObjectName(QString::fromUtf8("layoutWidget2"));
        layoutWidget2->setGeometry(QRect(360, 160, 101, 101));
        verticalLayout = new QVBoxLayout(layoutWidget2);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        pushButtonAdicionar = new QPushButton(layoutWidget2);
        pushButtonAdicionar->setObjectName(QString::fromUtf8("pushButtonAdicionar"));

        verticalLayout->addWidget(pushButtonAdicionar);

        pushButtonSubtrair = new QPushButton(layoutWidget2);
        pushButtonSubtrair->setObjectName(QString::fromUtf8("pushButtonSubtrair"));

        verticalLayout->addWidget(pushButtonSubtrair);

        pushButtonMultiplicar = new QPushButton(layoutWidget2);
        pushButtonMultiplicar->setObjectName(QString::fromUtf8("pushButtonMultiplicar"));

        verticalLayout->addWidget(pushButtonMultiplicar);

        tableWidgetResultado = new QTableWidget(centralwidget);
        if (tableWidgetResultado->columnCount() < 2)
            tableWidgetResultado->setColumnCount(2);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidgetResultado->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidgetResultado->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        if (tableWidgetResultado->rowCount() < 4)
            tableWidgetResultado->setRowCount(4);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tableWidgetResultado->setVerticalHeaderItem(0, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        tableWidgetResultado->setVerticalHeaderItem(1, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        tableWidgetResultado->setVerticalHeaderItem(2, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        tableWidgetResultado->setVerticalHeaderItem(3, __qtablewidgetitem5);
        tableWidgetResultado->setObjectName(QString::fromUtf8("tableWidgetResultado"));
        tableWidgetResultado->setGeometry(QRect(480, 280, 291, 192));
        pushButtonGrid = new QPushButton(centralwidget);
        pushButtonGrid->setObjectName(QString::fromUtf8("pushButtonGrid"));
        pushButtonGrid->setGeometry(QRect(790, 330, 75, 41));
        widget = new QWidget(centralwidget);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(360, 270, 101, 54));
        verticalLayout_2 = new QVBoxLayout(widget);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        pushButtonTranspostaA = new QPushButton(widget);
        pushButtonTranspostaA->setObjectName(QString::fromUtf8("pushButtonTranspostaA"));

        verticalLayout_2->addWidget(pushButtonTranspostaA);

        pushButtonTranspostaB = new QPushButton(widget);
        pushButtonTranspostaB->setObjectName(QString::fromUtf8("pushButtonTranspostaB"));

        verticalLayout_2->addWidget(pushButtonTranspostaB);

        widget1 = new QWidget(centralwidget);
        widget1->setObjectName(QString::fromUtf8("widget1"));
        widget1->setGeometry(QRect(350, 340, 115, 54));
        verticalLayout_3 = new QVBoxLayout(widget1);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        pushButtonPotencializacaoA = new QPushButton(widget1);
        pushButtonPotencializacaoA->setObjectName(QString::fromUtf8("pushButtonPotencializacaoA"));

        verticalLayout_3->addWidget(pushButtonPotencializacaoA);

        pushButtonPotencializacaoB = new QPushButton(widget1);
        pushButtonPotencializacaoB->setObjectName(QString::fromUtf8("pushButtonPotencializacaoB"));

        verticalLayout_3->addWidget(pushButtonPotencializacaoB);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 888, 21));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "SISTEMA DE OPER\303\207\303\225ES MATRICIAS", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:20pt; font-weight:600;\">MATRIZ A</span></p></body></html>", nullptr));
        pushButtonCriarMatA->setText(QCoreApplication::translate("MainWindow", "CRIAR", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:14pt;\">QUANTIDADE DE LINHAS</span></p></body></html>", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:14pt;\">QUANTIDADE DE COLUNAS</span></p></body></html>", nullptr));
        pushButtonCriarMatB->setText(QCoreApplication::translate("MainWindow", "CRIAR", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:14pt;\">QUANTIDADE DE LINHAS</span></p></body></html>", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:20pt; font-weight:600;\">MATRIZ B</span></p></body></html>", nullptr));
        label_6->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:14pt;\">QUANTIDADE DE COLUNAS</span></p></body></html>", nullptr));
        pushButtonAdicionar->setText(QCoreApplication::translate("MainWindow", "ADICIONAR", nullptr));
        pushButtonSubtrair->setText(QCoreApplication::translate("MainWindow", "SUBTRAIR", nullptr));
        pushButtonMultiplicar->setText(QCoreApplication::translate("MainWindow", "MULTIPLICAR", nullptr));
        QTableWidgetItem *___qtablewidgetitem = tableWidgetResultado->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QCoreApplication::translate("MainWindow", "MATRIZ A", nullptr));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidgetResultado->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QCoreApplication::translate("MainWindow", "MATRIZ B", nullptr));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidgetResultado->verticalHeaderItem(0);
        ___qtablewidgetitem2->setText(QCoreApplication::translate("MainWindow", "\303\211 Sim\303\251trica", nullptr));
        QTableWidgetItem *___qtablewidgetitem3 = tableWidgetResultado->verticalHeaderItem(1);
        ___qtablewidgetitem3->setText(QCoreApplication::translate("MainWindow", "\303\211 Identidade", nullptr));
        QTableWidgetItem *___qtablewidgetitem4 = tableWidgetResultado->verticalHeaderItem(2);
        ___qtablewidgetitem4->setText(QCoreApplication::translate("MainWindow", "\303\211 Igual", nullptr));
        QTableWidgetItem *___qtablewidgetitem5 = tableWidgetResultado->verticalHeaderItem(3);
        ___qtablewidgetitem5->setText(QCoreApplication::translate("MainWindow", "\303\211 Diferente", nullptr));
        pushButtonGrid->setText(QCoreApplication::translate("MainWindow", "GRID", nullptr));
        pushButtonTranspostaA->setText(QCoreApplication::translate("MainWindow", "TRANSPOSTA A", nullptr));
        pushButtonTranspostaB->setText(QCoreApplication::translate("MainWindow", "TRANSPOSTA B", nullptr));
        pushButtonPotencializacaoA->setText(QCoreApplication::translate("MainWindow", "POTENCIALIZA\303\207\303\203O A", nullptr));
        pushButtonPotencializacaoB->setText(QCoreApplication::translate("MainWindow", "POTENCIALIZA\303\207\303\203O B", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
